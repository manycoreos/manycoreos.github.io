module Main where
import Graphics.UI.WX
import Graphics.UI.WXCore hiding (Event)
import Data.Maybe
import System.IO
import Parse (parse_module)
import Data.Time
main :: IO ()
main = start gui

gui :: IO ()
gui = do 
        form   <- frame    [text := "Plagiarism Detector", clientSize := sz 200 200]
        p      <- panel form []

        mmenu <- menuPane    [text := "&Menu"]
        run <- menuItem mmenu [text := "&Run\tCtrl+r", help := "Detecting the Plagiarism Program"]
        save <- menuItem mmenu [text := "&Save\tCtrl+s", help := "Save result"]
        menuLine mmenu
        mquit <- menuQuit mmenu [help := "Quit the program"]
        -- grids
        g <- gridCtrl p []
        gridSetGridLineColour g (colorSystem Color3DFace)
        gridSetCellHighlightColour g black
        appendColumns g (head names)
        gridAutoSize g
        set g []
        windowReLayout p
        windowReLayout form
        set form [layout := container p $
                            column 0
                                [fill $ dynamic $ widget g]
                  , clientSize := sz 110 200
                  , menuBar := [mmenu]
                  , on (menu mquit) := close form
                  , on (menu run) := find form p g
                  , on (menu save) := saveGrid g form
                  ]
        windowReLayout p
        windowReLayout form                      

saveGrid g form
    = do
      n <- gridGetNumberRows g
      result <- mapM (\i -> gridGetRows i) [0..(n-1)]

      path <- fileSaveDialog form True True "Save Result" [("Any file",["*.*"])] "" ""
      --infoDialog form "Info" (fromJust path)

      outh <- openFile (fromJust path) WriteMode
      hPutStrLn outh "Similarity Score, Code 1, Code 2"
      sequence_ $ map (\s -> hPutStrLn outh s) result
      hClose outh
      infoDialog form "Info" "Save Complete"
      where
        gridGetRows i = do
                            s0 <- gridGetCellValue g i 0
                            s1 <- gridGetCellValue g i 1
                            s2 <- gridGetCellValue g i 2
                            return (s0 ++ ", " ++ s1 ++ ", " ++ s2)
            

find form p g = do 
            dir <- dirOpenDialog form True "Select Directory" ""
            stime <- getCurrentTime
            result <- parse_module ((fromJust dir) ++ "/")
            appendRows    g (map show [1..length (tail result)])
            mapM_ (setRow g) (zip [0..] (tail result))
            gridAutoSize g
            etime <- getCurrentTime
            infoDialog form "Time" (show (diffUTCTime etime stime))
            set g []
            windowReLayout p
            windowReLayout form
            return ()


names
  = [["Similarity Score", "Code 1", "Code 2"]]


setRow g (row,values)
  = mapM_ (\(col,value) -> gridSetCellValue g row col value) (zip [0..] values)


{--------------------------------------------------------------------------------
   Library?
--------------------------------------------------------------------------------}

gridCtrl :: Window a -> [Prop (Grid ())] -> IO (Grid ())
gridCtrl parent props
  = feed2 props 0 $
    initialWindow $ \id rect -> \props flags ->
    do g <- gridCreate parent id rect flags
       gridCreateGrid g 0 0 0
       set g props
       return g

gridEvent :: Event (Grid a) (EventGrid -> IO ())
gridEvent
  = newEvent "gridEvent" gridGetOnGridEvent gridOnGridEvent


gridMoveNext :: Grid a -> IO ()
gridMoveNext g
  = do row <- gridGetGridCursorRow g
       col <- gridGetGridCursorCol g
       rowCount <- gridGetNumberRows g
       colCount <- gridGetNumberCols g
       let (r,c) = if (row+1 >= rowCount)
                    then if (col+1 >= colCount)
                     then (0,0)
                     else (0,col+1)
                    else (row+1,col)
       gridSetGridCursor g r c
       gridMakeCellVisible g r c
       return ()

appendColumns :: Grid a -> [String] -> IO ()
appendColumns g []
  = return ()
appendColumns g labels
  = do n <- gridGetNumberCols g
       gridAppendCols g (length labels) True
       mapM_ (\(i,label) -> gridSetColLabelValue g i label) (zip [n..] labels)

appendRows :: Grid a -> [String] -> IO ()
appendRows g []
  = return ()
appendRows g labels
  = do n <- gridGetNumberRows g
       gridAppendRows g (length labels) True
       mapM_ (\(i,label) -> gridSetRowLabelValue g i label) (zip [n..] labels)
