module Parse where

import Text.ParserCombinators.Parsec (ParseError)
import Language.Java.Syntax
import Language.Java.Parser (parser, compilationUnit)
import JavaDNA (JavaDNA, visit)
import DNAComp (compDNA_P) 
import System.Directory
import Data.List
import Control.Parallel.Strategies
import System.IO


parseCompilationUnit :: String -> Either ParseError CompilationUnit
parseCompilationUnit =  parser compilationUnit
    
parse :: FilePath -> IO (Either ParseError CompilationUnit)
parse fn = fmap parseCompilationUnit (readFile fn)


parse_module dir = do
        result <- genDNA_dirP dir "java"
        return result

genDNA comp = case comp of
                Right c -> visit c
                Left msg -> "Error"

genDNA_dirP :: String -> String -> IO ([[String]])
genDNA_dirP dir extension
            = do
                files <- getDirectoryContents dir
                let file_list = filter (\x -> isInfixOf ("." ++ extension) x) files
                file_contents <- mapM (\x -> readFile (dir ++ x)) file_list 
                let parse_result = parMap rseq parseCompilationUnit file_contents
                let result = parMap rseq genDNA parse_result
                let result_pair = zip result file_list
                result <- compDNA_P result_pair
                return result
