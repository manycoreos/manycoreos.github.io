module DNAComp where
import Bio.Alignment.AAlign -- Align w/ Affine Gap Penalties
import Bio.Alignment.AlignData
import Bio.Alignment.QAlign
import Bio.Alignment.Matrices
import Bio.Sequence.SeqData
import Control.Monad
import qualified Data.ByteString.Lazy as B
import Data.ByteString.Internal (c2w, w2c)
import Data.List.Split
import Data.List
import qualified Data.Map as Map
import System.Directory
import Control.Parallel.Strategies
import Control.DeepSeq
import System.IO
import Control.Concurrent.ParallelIO.Global
import Numeric
import Data.Ord


toSeq id x = Seq (fromStr id) (fromStr x) Nothing

g = (-10,-1)

 
keywordMx :: (Num a) => a -> a -> (Chr,Chr) -> a
keywordMx match mis (x,y) = if x == y then match
                        else mis

local_alignment :: (Num a, Ord a) => String -> String -> a
local_alignment code1 code2 = Bio.Alignment.AAlign.local_score mt g s1 s2
                where
                    mt = keywordMx 1 (-1)
                    g = (-1,-1)
                    s1 = toSeq "A" code1
                    s2 = toSeq "B" code2

compDNA_P :: [(String,String)] -> IO ([[String]])
compDNA_P pairs
            = do
                let dnas = parMap rpar (\(x,y) -> x) pairs
                let dnaList = parMap rpar (\(x,y) -> y) pairs
                let procDNA = parMap rpar procToken2 dnas
                let dnaPairs = zip procDNA dnaList
                let testPairs = cartProduct dnaPairs dnaPairs
                let nomal_data = parMap rpar (\x -> local_alignment x x) procDNA
                let nomal_set = Map.fromList(zip dnaList nomal_data)
                
                let code_dna = parMap rseq (\((a,b),(c,d)) -> (a,c)) testPairs
                let code_name = parMap rseq  (\((a,b),(c,d)) -> (b,d)) testPairs
                let code_min = parMap rseq (\((a,b),(c,d)) -> select_value nomal_set b d) testPairs

                let simAB = parMap rseq (\(a,b) -> (local_alignment a b)) code_dna
                let sim = parMap rseq (\(a,b) -> (a / b)) (zip simAB code_min)
                let mid_result = zip sim code_name
               
                let sorted_result = reverse $ sortBy (comparing fst) mid_result
                let result = parMap rseq (\(r,(f1,f2)) -> [(change_notation r)] ++ [f1] ++ [f2]) sorted_result
                return result
                where change_notation r = showFFloat Nothing r ""

cartProduct _ [] = []
cartProduct [] _ = []
cartProduct (a:as) (b:bs) = sum a bs ++ cartProduct as bs
                where   sum _ [] = []
                        sum x (y:zs) = [(x,y)] ++ sum x zs

select_value h a b = min x y
                    where x = case Map.lookup a h of
                                Nothing -> 0
                                Just v1 -> v1
                          y = case Map.lookup b h of
                                Nothing -> 0
                                Just v2 -> v2

procToken :: String -> String
procToken str = foldl (++) "" result
                where
                    result = parMap rpar change_c_key trim_split
                    trim_split = map (\x -> head(splitOn "\t" x)) splits
                    splits = lines str
procToken2 :: String -> String
procToken2 str = foldl (++) "" result
                where
                    result = parMap rseq change_java_key trim_split
                    trim_split = splitOn "\n" str

change_java_key :: String -> String
change_java_key "ASSIGN_EQ" = " "
change_java_key "TIMES_EQ" = "!"
change_java_key "DIV_EQ" = "#"
change_java_key "MOD_EQ" = "$"
change_java_key "PLUS_EQ" = "%"
change_java_key "MINUS_EQ" = "&"
change_java_key "SHL_EQ" = "'"
change_java_key "SHR_EQ" = "("
change_java_key "BITAND_EQ" = ")"
change_java_key "BITXOR_EQ" = "*"
change_java_key "BITOR_EQ" = "+"
change_java_key "OR" = ","
change_java_key "AND" = "-"
change_java_key "BIT_OR" = "."
change_java_key "BIT_XOR" = "/"
change_java_key "BIT_AND" = "0"
change_java_key "NOT_EQ" = "1"
change_java_key "EQ" = "2"
change_java_key "LT" = "3"
change_java_key "GT" = "4"
change_java_key "LT_EQ" = "5"
change_java_key "GT_EQ" = "6"
change_java_key "SHL" = "7"
change_java_key "SHR" = "8"
change_java_key "PLUS" = "9"
change_java_key "MINUS" = ":"
change_java_key "MULTIPLE" = ";"
change_java_key "DIVIDE" = "<"
change_java_key "MOD" = "="
change_java_key "INCR" = ">"
change_java_key "DECR" = "?"
change_java_key "PTR" = "@"
change_java_key "NOT" = "A"
change_java_key "VOID" = "B"
change_java_key "INT" = "C"
change_java_key "CHAR" = "D"
change_java_key "BOOL" = "E"
change_java_key "SHORT" = "F"
change_java_key "FLOAT" = "G"
change_java_key "DOUBLE" = "H"
change_java_key "SIGNED" = "I"
change_java_key "LONG" = "J"
change_java_key "UNSIGNED" = "K"
change_java_key "DO" = "L"
change_java_key "STRUCT" = "M"
change_java_key "STATIC" = "N"
change_java_key "CONTINUE" = "O"
change_java_key "SWITCH" = "P"
change_java_key "CASE" = "Q"
change_java_key "DEFAULT" = "R"
change_java_key "BREAK" = "S"
change_java_key "RETURN" = "T"
change_java_key "GOTO" = "U"
change_java_key "TYPEDEF" = "V"
change_java_key "SIZEOF" = "W"
change_java_key "CONST" = "X"
change_java_key "VOLATILE" = "Y"
change_java_key "INLINE" = "Z"
change_java_key "PUBLIC" = "["
change_java_key "PRIVATE" = "]"
change_java_key "FRIEND" = "^"
change_java_key "PROTECTED" = "_"
change_java_key "NEW" = "`"
change_java_key "DELETE" = "a"
change_java_key "VIRTUAL" = "b"
change_java_key "TRY" = "c"
change_java_key "CATCH" = "d"
change_java_key "THROW" = "e"
change_java_key "TRUE" = "f"
change_java_key "FALSE" = "g"
change_java_key "CLASS" = "h"
change_java_key "NAMESPACE" = "i"
change_java_key "IF" = "j"
change_java_key "ELSE" = "k"
change_java_key "FOR" = "l"
change_java_key "WHILE" = "m"
change_java_key "BLOCK_START" = "n"
change_java_key "BLOCK_END" = "o"
change_java_key "FUNC_CALL" = "p"
change_java_key "FUNC_END" = "q"
change_java_key "UNTRACKABLE_FUNC_CALL" = "r"
change_java_key "INTERFACE" = "s"
change_java_key "CLASS_REF" = "t"
change_java_key "STRICT" = "u"
change_java_key "ENUM" = "v"
change_java_key "ASSERT" = "w"
change_java_key "" = ""
--change_java_ket str = case str of
--    _ -> "Error" ++ str
--change_java_key _ = "Error"

change_c_key :: String -> String
change_c_key "ASSIGN_EQ" = " "
change_c_key "TIMES_EQ" = "!"
change_c_key "DIV_EQ" = "#"
change_c_key "MOD_EQ" = "$"
change_c_key "PLUS_EQ" = "%"
change_c_key "MINUS_EQ" = "&"
change_c_key "SHL_EQ" = "'"
change_c_key "SHR_EQ" = "("
change_c_key "BITAND_EQ" = ")"
change_c_key "BITXOR_EQ" = "*"
change_c_key "BITOR_EQ" = "+"
change_c_key "OR" = ","
change_c_key "AND" = "-"
change_c_key "BIT_OR" = "."
change_c_key "BIT_XOR" = "/"
change_c_key "BIT_AND" = "0"
change_c_key "NOT_EQ" = "1"
change_c_key "EQ" = "2"
change_c_key "LT" = "3"
change_c_key "GT" = "4"
change_c_key "LT_EQ" = "5"
change_c_key "GT_EQ" = "6"
change_c_key "SHL" = "7"
change_c_key "SHR" = "8"
change_c_key "PLUS" = "9"
change_c_key "MINUS" = ":"
change_c_key "MULTIPLE" = ";"
change_c_key "DIVIDE" = "<"
change_c_key "MOD" = "="
change_c_key "INCR" = ">"
change_c_key "DECR" = "?"
change_c_key "PTR" = "@"
change_c_key "NOT" = "A"
change_c_key "VOID" = "B"
change_c_key "INT" = "C"
change_c_key "CHAR" = "D"
change_c_key "BOOL" = "E"
change_c_key "SHORT" = "F"
change_c_key "FLOAT" = "G"
change_c_key "DOUBLE" = "H"
change_c_key "SIGNED" = "I"
change_c_key "LONG" = "J"
change_c_key "UNSIGNED" = "K"
change_c_key "DO" = "L"
change_c_key "STRUCT" = "M"
change_c_key "STATIC" = "N"
change_c_key "CONTINUE" = "O"
change_c_key "SWITCH" = "P"
change_c_key "CASE" = "Q"
change_c_key "DEFAULT" = "R"
change_c_key "BREAK" = "S"
change_c_key "RETURN" = "T"
change_c_key "GOTO" = "U"
change_c_key "TYPEDEF" = "V"
change_c_key "SIZEOF" = "W"
change_c_key "CONST" = "X"
change_c_key "VOLATILE" = "Y"
change_c_key "INLINE" = "Z"
change_c_key "PUBLIC" = "["
change_c_key "PRIVATE" = "]"
change_c_key "FRIEND" = "^"
change_c_key "PROTECTED" = "_"
change_c_key "NEW" = "`"
change_c_key "DELETE" = "a"
change_c_key "VIRTUAL" = "b"
change_c_key "TRY" = "c"
change_c_key "CATCH" = "d"
change_c_key "THROW" = "e"
change_c_key "TRUE" = "f"
change_c_key "FALSE" = "g"
change_c_key "CLASS" = "h"
change_c_key "NAMESPACE" = "i"
change_c_key "IF" = "j"
change_c_key "ELSE" = "k"
change_c_key "FOR" = "l"
change_c_key "WHILE" = "m"
change_c_key "BLOCK_START" = "n"
change_c_key "BLOCK_END" = "o"
change_c_key "FUNC_CALL" = "p"
change_c_key "FUNC_END" = "q"
change_c_key "UNTRACKABLE_FUNC_CALL" = "r"
