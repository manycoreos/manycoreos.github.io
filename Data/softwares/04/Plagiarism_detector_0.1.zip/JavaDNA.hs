module JavaDNA where


import Language.Java.Syntax



class JavaDNA a where
--    visitAST :: a -> String
--    visitAST t = visit 0

    visit ::  a -> String
--    visit _ = visitAST


instance JavaDNA CompilationUnit where
  visit (CompilationUnit mpd ids tds) = 
    foldl (++) "" (map (visit) tds)

--instance JavaDNA PackageDecl where
--  visit (PackageDecl name) = text "package" <+> visit name <> semi
--instance JavaDNA ImportDecl where
--  visit (ImportDecl st name wc) =
instance JavaDNA TypeDecl where
  visit (ClassTypeDecl     cd) = visit cd
  visit (InterfaceTypeDecl id) = visit id

instance JavaDNA ClassDecl where
  visit (ClassDecl mods ident tParams mSuper impls body) = 
    "CLASS\n" ++ "BLOCK_START\n" ++ visit body ++ "BLOCK_END\n"
  visit (EnumDecl mods ident impls body) = "ENUM\n" ++ "BLOCK_START\n" ++ visit body ++ "BLOCK_END\n"

instance JavaDNA ClassBody where
  visit (ClassBody ds)  = foldl (++) "" (map visit ds)


instance JavaDNA EnumBody where
  visit (EnumBody cs ds) = foldl (++) "" (map visit cs) ++ foldl (++) "" (map visit ds)

instance JavaDNA EnumConstant where
  visit (EnumConstant ident args mBody) = maybe [] visit mBody

instance JavaDNA InterfaceDecl where
  visit (InterfaceDecl mods ident tParams impls body) = "INTERFACE\n" ++ "BLOCK_START\n" ++ visit body ++ "BLOCK_END\b"

instance JavaDNA InterfaceBody where
  visit (InterfaceBody mds) = foldl (++) "" (map visit mds)

instance JavaDNA Decl where
  visit (MemberDecl md) = visit md
  visit (InitDecl b bl) = visit bl

instance JavaDNA MemberDecl where
  visit (MethodDecl mods tParams mt ident fParams throws body) =
    foldl (++) "" (map visit mods) ++ (ppResultType mt) ++ "BLOCK_START\n" ++ visit body ++ "BLOCK_END\n"
  visit (FieldDecl mods t vds) = ""
  visit (ConstructorDecl mods tParams ident fParams throws body) = "BLOCK_START\n" ++ visit body ++ "BLOCK_END\n"
  visit (MemberClassDecl cd) = visit cd
  visit (MemberInterfaceDecl id) = visit id

instance JavaDNA VarDecl where
  visit (VarDecl vdId Nothing) = ""--visit vdId
  visit (VarDecl vdId (Just ie)) = visit ie

instance JavaDNA VarDeclId where
  visit (VarId ident) = ""--visit ident
  visit (VarDeclArray vId) = visit vId

instance JavaDNA VarInit where
  visit (InitExp e) = ppInitType (visit e)
  visit (InitArray (ArrayInit ai)) = ""--foldl (++) (map visit ai)

instance JavaDNA FormalParam where
  visit (FormalParam mods t b vId) = ""

instance JavaDNA MethodBody where
    visit (MethodBody mBlock) = maybe [] visit mBlock

instance JavaDNA ConstructorBody where
  visit (ConstructorBody mECI stmts) = "BLOCK_START\n" ++ foldl (++) "" (map visit stmts) ++ "BLOCK_END\n"

instance JavaDNA ExplConstrInv where
  visit (ThisInvoke rts args) = ""
  visit (SuperInvoke rts args) = ""
  visit (PrimarySuperInvoke e rts args) = ""

instance JavaDNA Modifier where
  visit modi = case modi of
    Public  -> ""
    Private  -> ""
    Protected  -> ""
    Abstract -> ""
    Final -> ""
    Static  -> "STATIC\n"
    StrictFP  -> "STRICT\n"
    Transient -> ""
    Volatile  -> "VOLATILE\n"
    Native  -> ""
    (Annotation ann) -> ""
    --Annotation Annotation    
    Synchronised -> ""
  --visit (Annotation ann) = visit ann $+$ nest (-1) ( text "")

--instance JavaDNA Annotation where
--  visit x = text "@" <> visit (annName x) <> case x of
--         SingleElementAnnotation {} -> text "(" <> visit (annValue x) <> text ")"  

--instance JavaDNA ElementValue where
--  visit (EVVal vi) = visit vi
--  visit (EVAnn ann) = visit ann

instance JavaDNA Block where
    visit (Block stmts) = "BLOCK_START\n" ++ foldl (++) "" (map visit stmts) ++ "BLOCK_END\n"

instance JavaDNA BlockStmt where
  visit (BlockStmt stmt) = visit stmt
  visit (LocalClass cd) = visit cd
  visit (LocalVars mods t vds) = foldl (++) "" (map visit vds)

instance JavaDNA Stmt where
  visit (StmtBlock block) = visit block
  visit (IfThen c th) = "IF\n" ++ visit th
  visit (IfThenElse c th el) = "IF\n"  ++ visit th ++ "ELSE\n" ++ visit el
  visit (While c stmt) = "WHILE\n" ++ visit stmt
  visit (BasicFor mInit mE mUp stmt) = "FOR\n" ++ visit stmt
  visit (EnhancedFor mods t ident e stmt) = "FOR\n" ++ visit stmt
  visit (ExpStmt e) = visit e
  visit (Assert ass mE) = "ASSERT\n" ++ maybe [] visit mE
  visit (Switch e sBlocks) = "SWITCH\n" ++ foldl (++) "" (map visit sBlocks)
  visit (Do stmt e) = "WHILE\n" ++ visit stmt
  visit (Break mIdent) = "BREAK\n"
  visit (Continue mIdent) = "CONTINUE\n"
  visit (Return mE) = "RETURN\n"
  visit (Synchronized e block) = visit block
  visit (Throw e) = ""
  visit (Try block catches mFinally) = visit block ++ foldl (++) "" (map visit catches) ++ maybe [] visit mFinally
  visit (Labeled ident stmt) = ""
  visit Empty = ""

instance JavaDNA Catch where
  visit (Catch fParam block) = "CATCH\n" ++ visit block

instance JavaDNA SwitchBlock where
  visit (SwitchBlock lbl stmts) = foldl (++) "" (map visit stmts)

instance JavaDNA SwitchLabel where
  visit (SwitchCase e) = ""

instance JavaDNA ForInit where
  visit (ForLocalVars mods t vds) = foldl (++) "" (map visit vds)
  visit (ForInitExps es) = foldl (++) ""  (map visit es)

instance JavaDNA Exp where
  visit (Lit l) = "" --visit l
  visit (ClassLit mT) = ""
  visit (ThisClass name) = ""
  visit (InstanceCreation tArgs ct args mBody) = ""
  visit (QualInstanceCreation e tArgs ident args mBody) = ""
  visit (ArrayCreate t es k) = ""
  visit (ArrayCreateInit t k init) = ""
  visit (FieldAccess fa) = ""
  visit (MethodInv mi) = visit mi
  visit (ArrayAccess ain) = ""
  visit (ExpName name) = ""
  visit (PostIncrement e) = "INCR\n"
  visit (PostDecrement e) = "DECR\n"
  visit (PreIncrement e)  = "INCR\n"
  visit (PreDecrement e)  = "DECR\n"
  visit (PrePlus e) = ""
  visit (PreMinus e) = ""
  visit (PreBitCompl e) = ""
  visit (PreNot e) = ""
  visit (Cast t e) = ""
  visit (BinOp e1 op e2) = visit e1 ++ visit op ++ visit e1
  visit (InstanceOf e rt) =""
  visit (Cond c th el) = ""
  visit (Assign lhs aop e) = visit aop ++ visit e
instance JavaDNA Literal where
  --visit (Int i) = text (show i)
  --visit (Word i) = text (show i) <> char 'L'
  --visit (Float f) = text (show f) <> char 'F'
  --visit (Double d) = text (show d)
  --visit (Boolean b) = text . map toLower $ show b
  --visit (Char c) = quotes $ text (escapeChar c)
  --visit (String s) = doubleQuotes $ text (concatMap escapeString s)
  --visit (Null) = text "null"
instance JavaDNA Op where
  visit op = case op of
    Mult    -> "MULTIPLE\n"
    Div     -> "DIVIDE\n"
    Rem     -> "MOD\n"
    Add     -> "PLUS\n"
    Sub     -> "MINUS\n"
    LShift  -> "SHL\n"
    RShift  -> "SHR\n"
    RRShift -> "SHRR\n"
    LThan   -> "LT\n"
    GThan   -> "GT\n"
    LThanE  -> "LT_EQ\n"
    GThanE  -> "GT_EQ\n"
    Equal   -> "EQ\n"
    NotEq   -> "NOT_EQ\n"
    And     -> "BIT_AND\n"
    Xor     -> "BIT_XOR\n"
    Or      -> "BIT_OR\n"
    CAnd    -> "AND\n"
    COr     -> "OR\n"

instance JavaDNA AssignOp where
  visit aop = case aop of
    EqualA  -> "ASSIGN_EQ\n"
    MultA   -> "TIMES_EQ\n"
    DivA    -> "DIV_EQ\n"
    RemA    -> "MODE_EQ\n"
    AddA    -> "PLUS_EQ\n"
    SubA    -> "MINUS_EQ\n"
    LShiftA -> "SHL_EQ\n"
    RShiftA -> "SHR_EQ\n"
    RRShiftA -> "SHR_EQ\n"
    AndA    -> "BITAND_EQ\n"
    XorA    -> "BITXOR_EQ\n"
    OrA     -> "BITOR_EQ\n"

instance JavaDNA Lhs where
  visit (NameLhs name) = ""
  visit (FieldLhs fa) = ""
  visit (ArrayLhs ain) = ""

instance JavaDNA ArrayIndex where
  visit (ArrayIndex ref e) = ""--visit ref <> (hcat $ map (brackets . (visit)) e)

instance JavaDNA FieldAccess where
  visit (PrimaryFieldAccess e ident) = ""
  visit (SuperFieldAccess ident) = ""
  visit (ClassFieldAccess name ident) = ""

instance JavaDNA MethodInvocation where
  visit (MethodCall name args) = "FUNC_CALL\n"
  visit (PrimaryMethodCall e tArgs ident args) = "FUNC_CALL\n"
  visit (SuperMethodCall tArgs ident args) = "FUNC_CALL\n"
  visit (ClassMethodCall name tArgs ident args) = "FUNC_CALL\n"
  visit (TypeMethodCall name tArgs ident args) = "FUNC_CALL\n"

instance JavaDNA ArrayInit where
  visit (ArrayInit vInits) = ""

instance JavaDNA Type where
  visit (PrimType pt) = visit pt
  visit (RefType  rt) = visit rt

instance JavaDNA RefType where
  visit (ClassRefType ct) = "CLASS_REF\n"
  visit (ArrayType t) = visit t

instance JavaDNA ClassType where
  visit (ClassType itas) = ""

instance JavaDNA TypeArgument where
  visit (ActualType rt) = ""
  visit (Wildcard mBound) = ""

instance JavaDNA WildcardBound where
  visit (ExtendsBound rt) = ""
  visit (SuperBound   rt) = ""

instance JavaDNA PrimType where
  visit BooleanT = "BOOL\n"
  visit ByteT    = "BYTE\n"
  visit ShortT   = "SHORT\n"
  visit IntT     = "INT\n"
  visit LongT    = "LONG\n"
  visit CharT    = "CHAR\n"
  visit FloatT   = "FLOAT\n"
  visit DoubleT  = "DOUBLE\n"
--instance JavaDNA TypeParam where
-- visit (TypeParam ident rts) =
--instance JavaDNA Name where
 -- visit (Name is) =
--instance JavaDNA Ident where
--  visit (Ident s) = text s

ppResultType :: Maybe Type -> String
ppResultType Nothing = "VOID\n"
ppResultType (Just a) = visit a

ppInitType :: String -> String
ppInitType s1 = case s1 of
  "" -> "ASSIGN_EQ\n"
  "MULTIPLE\n" -> "TIMES_EQ\n"
  "DIVIDE\n" -> "DIV_EQ\n"
  "MOD\n" -> "MODE_EQ\n"
  "PLUS\n" -> "PLUS_EQ\n"
  "MINUS\n" -> "MINUS_EQ\n"
  "SHL\n" -> "SHL_EQ\n"
  "SHR\n" -> "SHR_EQ\n"
  "SHRR\n" -> "SHRR_EQ\n"
  "BIT_AND\n" -> "BITAND_EQ\n"
  "BIT_XOR\n" -> "BITXOR_EQ\n"
  "BIT_OR\n" -> "BITOR_EQ\n"
  "FUNC_CALL\n" -> "ASSIGN_EQ\n"
  _ -> s1 ++ "\n" 
