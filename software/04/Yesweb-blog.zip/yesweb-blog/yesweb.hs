{-# LANGUAGE DeriveDataTypeable,
			 GADTs,
			 FlexibleContexts,
			 QuasiQuotes,
			 MultiParamTypeClasses,
			 OverloadedStrings,
			 GeneralizedNewtypeDeriving,
			 ViewPatterns,
			 TypeFamilies,
			 TemplateHaskell
			 #-}
import Data.Time (UTCTime, getCurrentTime)
import Control.Applicative ((<$>), (<*>), pure)
import Data.Typeable (Typeable)
import Control.Monad.Logger (runStdoutLoggingT)
import Control.Parallel
import Control.Concurrent
import Network.HTTP.Client.TLS (tlsManagerSettings)
import Network.HTTP.Conduit (Manager, newManager)
import Database.Persist.Sqlite
    ( ConnectionPool, SqlBackend, runSqlPool, runMigration
    , createSqlitePool, runSqlPersistMPool
    )
import Yesod.Core.Handler
import Yesod.Form.Nic (YesodNic, nicHtmlField)
import Yesod.Auth.BrowserId (authBrowserId, def)
import Data.Text (Text)
import Yesod
import Yesod.Auth
import Yesod.Static
-- import Yesod.Helpers.Static
-- import Settings.StaticFiles
-- import Yesod.Auth.Account
staticFiles "static"
share [mkPersist sqlSettings, mkMigrate "migrateAll"] [persistLowerCase|
Visitor
    mailAddr Text
    UniqueUser mailAddr
    deriving Typeable
Article
    heading Text
    publish UTCTime
    details Html
Guestbook
    article ArticleId
    publish UTCTime
    visitor VisitorId
    name Text
    text Textarea
|]

data YesBlog = YesBlog
	{ dbTable :: ConnectionPool, webHandler :: Manager, getStatic :: Static}

mkMessage "YesBlog" "system-content" "en"

mkYesod "YesBlog" [parseRoutes|
/	IndexR	GET
/list	ListR	GET POST
/list/#ArticleId	ListEntryR	GET POST
/check	CheckIdR	Auth	getAuth
/static StaticR Static getStatic
|]

instance Yesod YesBlog where
    approot = ApprootStatic "http://localhost:5110"
    isAuthorized ListR True = do
        hasRight <- maybeAuth
        case hasRight of
            Nothing -> return AuthenticationRequired
            Just (Entity _ visitor)
                | isManager visitor -> return Authorized
                | otherwise -> unauthorizedI MsgNotAnAdmin
    isAuthorized (ListEntryR _) True = do
        hasRight <- maybeAuth
        case hasRight of
            Nothing -> return AuthenticationRequired
            Just _ -> return Authorized
    isAuthorized _ _ = return Authorized
    authRoute _ = Just (CheckIdR LoginR)
    defaultLayout inside = do
        mmsg <- getMessage
        pc <- widgetToPageContent $ do
            toWidget [lucius|
body {
    width: 1000px;
    margin: 6em auto;
    font-family: sans-serif;
}
textarea {
    width: 600px;
    height: 300px;
}
#message {
    color: #900;
}
|]
            inside
        withUrlRenderer [hamlet|
$doctype 5
<html>
    <head>
        <title>#{pageTitle pc}
        ^{pageHead pc}
    <body background="@{StaticR background_png}">
        $maybe msg <- mmsg
            <div #message>#{msg}
        ^{pageBody pc}
|]

articleF :: Form Article
articleF = renderDivs $ Article
    <$> areq textField (fieldSettingsLabel MsgNewEntryTitle) Nothing
    <*> lift (liftIO getCurrentTime)
    <*> areq nicHtmlField (fieldSettingsLabel MsgNewEntryContent) Nothing

getListR :: Handler Html
getListR = do
    previsitor <- maybeAuth
    articles <- runDB $ selectList [] [Desc ArticlePublish]
    (articleWidget, enctype) <- generateFormPost articleF
    defaultLayout $ do
        setTitleI MsgBlogArchiveTitle
        [whamlet|
$if null articles
    <p>_{MsgNoEntries}
$else
    <ul>
        $forall Entity articleId article <- articles
            <li>
                <a href=@{ListEntryR articleId}>#{articleHeading article}
$maybe Entity _ visitor <- previsitor
    $if isManager visitor
        <form method=post enctype=#{enctype}>
            ^{articleWidget}
            <div>
                <input type=submit value=_{MsgNewEntry}>
$nothing
    <p>
        <a href=@{CheckIdR LoginR}>_{MsgLoginToPost}
|]

isManager :: Visitor -> Bool
isManager visitor = visitorMailAddr visitor == "liuxiao@pusan.ac.kr"
instance YesodPersist YesBlog where
    type YesodPersistBackend YesBlog = SqlBackend
    runDB f = do
        master <- getYesod
        let pool = dbTable master
        runSqlPool f pool

postListR :: Handler Html
postListR = do
    ((res, articleWidget), enctype) <- runFormPost articleF
    case res of
        FormSuccess article -> do
            articleId <- runDB $ insert article
            setMessageI $ MsgEntryCreated $ articleHeading article
            redirect $ ListEntryR articleId
        _ -> defaultLayout $ do
            setTitleI MsgPleaseCorrectEntry
            [whamlet|
<form method=post enctype=#{enctype}>
    ^{articleWidget}
    <div>
        <input type=submit value=_{MsgNewEntry}>
|]

guestbookF :: ArticleId -> Form Guestbook
guestbookF articleId = renderDivs $ Guestbook
    <$> pure articleId
    <*> lift (liftIO getCurrentTime)
    <*> lift requireAuthId
    <*> areq textField (fieldSettingsLabel MsgCommentName) Nothing
    <*> areq textareaField (fieldSettingsLabel MsgCommentText) Nothing

getListEntryR :: ArticleId -> Handler Html
getListEntryR articleId = do
    (article, guestbooks) <- runDB $ do
        article <- get404 articleId
        guestbooks <- selectList [GuestbookArticle ==. articleId] [Asc GuestbookPublish]
        return (article, map entityVal guestbooks)
    previsitor <- maybeAuth
    (commentWidget, enctype) <-
        generateFormPost (guestbookF articleId)
    defaultLayout $ do
        setTitleI $ MsgEntryTitle $ articleHeading article
        [whamlet|
<h1>#{articleHeading article}
<article>#{articleDetails article}
    <section .guestbooks>
        <h1>_{MsgCommentsHeading}
        $if null guestbooks
            <p>_{MsgNoComments}
        $else
            $forall Guestbook _entry publish _visitor name text <- guestbooks
                <div .guestbook>
                    <span .by>#{name}
                    <span .at>#{show publish}
                    <div .details>#{text}
        <section>
            <h1>_{MsgAddCommentHeading}
            $maybe _ <- previsitor
                <form method=post enctype=#{enctype}>
                    ^{commentWidget}
                    <div>
                        <input type=submit value=_{MsgAddCommentButton}>
            $nothing
                <p>
                    <a href=@{CheckIdR LoginR}>_{MsgLoginToComment}
|]

type Form x = Html -> MForm Handler (FormResult x, Widget)
instance RenderMessage YesBlog FormMessage where
    renderMessage _ _ = defaultFormMessage

instance YesodNic YesBlog

instance YesodAuth YesBlog where
    type AuthId YesBlog = VisitorId
    loginDest _ = IndexR
    logoutDest _ = IndexR
    authHttpManager = webHandler
    authPlugins _ = [authBrowserId def]
    getAuthId creds = do
        let mailAddr = credsIdent creds
            visitor = Visitor mailAddr
        res <- runDB $ insertBy visitor
        return $ Just $ either entityKey id res

instance YesodAuthPersist YesBlog

getIndexR = defaultLayout $ do
    setTitleI MsgHomepageTitle
    [whamlet|
<p>_{MsgWelcomeHomepage}
<p>
    <a href=@{ListR}>_{MsgSeeArchive}
|]

postListEntryR :: ArticleId -> Handler Html
postListEntryR articleId = do
    ((res, commentWidget), enctype) <-
        runFormPost (guestbookF articleId)
    case res of
        FormSuccess guestbook -> do
            _ <- runDB $ insert guestbook
            setMessageI MsgCommentAdded
            redirect $ ListEntryR articleId
        _ -> defaultLayout $ do
            setTitleI MsgPleaseCorrectComment
            [whamlet|
<form method=post enctype=#{enctype}>
    ^{commentWidget}
    <div>
        <input type=submit value=_{MsgAddCommentButton}>
|]

main :: IO ()
main = do
    pool <- runStdoutLoggingT $ createSqlitePool "yesweb.db5" 10 -- create a new pool
    -- perform any necessary migration
    runSqlPersistMPool (runMigration migrateAll) pool
    controller <- newManager tlsManagerSettings -- create a new HTTP manager
    static@(Static settings) <- static "static"
    warp 5110 $ YesBlog pool controller static -- start our server