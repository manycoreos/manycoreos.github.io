## A Manual of How to Setup & Use YesWeb-Blog on Windows

- Download and install Haskell platform for Windows (includes GCH and Cabal)
	- url: https://www.haskell.org/platform/windows.html
- Packages installation
	- Update Cabal package list
		- run command `cabal update`  on Windows Command Prompt
  - Install yesod packages
	  - run command `cabal install yesod yesod-bin` on Windows Command Prompt
  - install other necessary packages
	  - run command `cabal install persistent-sqlite` to install sqlite database package
	  - run command `install yesod-static` to install yesod static package
  - Notice
	Since the newest version of Haskell platform contains Parallel and Concurrent packages as default, users have no necessary to install them independently.

#### - Setup user information
- Open the yesweb.hs file in yesweb-blog/ folder with your favorite code editor.
- Change the default manager ID at line 144, a sample change is like below.
```haskell
		#default_setting
		isManager visitor = visitorMailAddr visitor == "liuxiao@pusan.ac.kr"
		#your_new_setting
		isManager visitor = visitorMailAddr visitor == "your@own.email"
```
   - Please note the user authentication function may not work well when you set up the YesWeb-Blog url as 'localhost', in somehow it keep making the Persona plugin showing error, so if it possible, you may need to change the application url to your own IP which supposed to run this application, a sample modification of how to change url is like below.
```haskell
#default_setting
approot = ApprootStatic "http://localhost:5110"
#your_new_setting
approot = ApprootStatic "http://192.168.0.1:5110"
```
- Run the YesWeb-Blog application
	- Open the Windows Command Prompt in the yesweb-blog/ folder
	- Run command `ghc -threaded -rtsopts -eventlog yesweb.hs` command to compile the source code
	- If all goes well, a executable program 'yesweb.exe' and other related files will be generated.
	- Run command `yesweb.exe +RTS -Nx` (x is a number depends on how many cores you want to use on this program) to start the YesWeb-Blog application server.
	- If all goes well, the messages of database tables generation will be printed out.
	- Since the default url of this application was set as 'localhost' and default port is 5110 **(which you can change them in source code)**, open your favorite Web browser to access 'http://localhost:5110' then you will see the home page of YesWeb-Blog. 
	- Click on the 'See the articles' button and then you will be routed to the login check page
	- Click on the 'Admins can login to publish' button to login using author ID
	- The first login will require you to set the password, you can set any password you want for login at next time. 
	- The Perona plugin may require an email authentication that you will receive an email which you set on the source code, and you need to confirm it for completing the authentication.
	- After login, you can use all the functions of this application such as write & publish an article, upload a comment, etc.

Enjoy with this application!

Xiao Liu
Jan 27, 2016