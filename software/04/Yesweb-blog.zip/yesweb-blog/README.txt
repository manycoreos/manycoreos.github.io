About this documentation
------------------------

This documentation provides all of the necessary information related the YesWeb-Blog project including the APPLICATION INTRODUCTION of YesWeb-Blog, ENVIRONMENT REQUIREMENT for running YesWeb-Blog, the PROGRAM LICENCE, and the CONTACT WAY of us.


APPLICATION INTRODUCTION
------------------------

This application called YesWeb-Blog is a Web blog application developed using Haskell for verifying the parallel & concurrent performance of Haskell, and presenting the convenience of Web application development through Yesod and Warp which are two packages of Haskell.

YesWeb-Blog has most common blog functions such as article writing & publishing, comment upload, contents management, etc.


ENVIRONMENT REQUIREMENT
-----------------------

OS requirement:
Recommended: Linux (RedHat family or Debian family)
Others: Windows (7 or later), Mac OS X (10.8 or later)

Haskell platform: GHC (7.8 or later), Cabal (1.22.4.0)

Required packages:
Yesod main packages: you can see the details of Yesod and learn how to install them on http://www.yesodweb.com/page/quickstart which introduced the installation of yesod on Linux. We also made a user guide for Windows users which is contained with this documentation at same folder and has both of markdown format and PDF format.

Persistent-Sqlite package: you can install this package using cabal after the yesod package installation

Yesod-Static package: you can install this package using cabal after the Persistent-Sqlite package installation

Since Haskell with its GHC compiler support cross-platform, YesWeb-Blog could be launched at whether Linux, Windows or Mac OS X. Please note that we only tested YesWeb-Blog at Linux and Windows that ran well at both of those platforms, so theoretically this application will also run well at Mac OS X.

PROGRAM LICENCE
---------------

Since YesWeb-Blog referred lot from the web site www.yesodweb.com, same as all the contents in that site YesWeb-Blog follows the Creative Commons Attribution 4.0 International License (http://creativecommons.org/licenses/by/4.0/).

CONTACT WAY
-----------

if you have any inquiry please feel free to contact us.

Workplace: Department of Electrical and Computer Engineering, Pusan National University
Email: pllab@pusan.ac.kr

Author: Xiao Liu
Email: liuxiao@pusan.ac.kr


Jan 27, 2016
